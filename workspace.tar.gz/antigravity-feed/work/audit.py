#!/usr/bin/env python3
"""Final self-audit: integrity, arithmetic, internal references, Antigravity limits.
Run after any regeneration. Exits non-zero if anything fails."""
import json, os, re, glob, csv, collections, ipaddress, urllib.parse, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
os.chdir(ROOT)
f = lambda n: f"{n:,}"
fails = []
def chk(ok, label):
    print(f"  {'PASS' if ok else 'FAIL'}  {label}")
    if not ok: fails.append(label)

L = json.load(open("data/links.json", encoding="utf-8"))["links"]
S = json.load(open("data/stats.json", encoding="utf-8"))
N = json.load(open(os.path.join(HERE, "final_numbers.json"), encoding="utf-8"))
V = json.load(open(os.path.join(HERE, "validated.json"), encoding="utf-8"))["candidates"]
rules = sorted(glob.glob("antigravity/.agents/rules/*.md"))
urls = [r["url"] for r in L]
lines = lambda p: sum(1 for _ in open(p, encoding="utf-8"))

print("=== 1. corpus integrity ===")
bul = sum(sum(1 for l in open(rf, encoding="utf-8") if l.startswith("- ")) for rf in rules) - 6
n_csv = len(list(csv.DictReader(open("data/links.csv", encoding="utf-8"))))
chk(len(urls) == lines("data/all-links.txt") == n_csv == bul == N["total"] == S["final_kept"],
    f"count identical across links.json / all-links.txt / links.csv / rule bullets  ({f(len(urls))})")
chk(len(urls) == len(set(urls)), "no duplicate URLs")
chk(all(u.startswith("http") for u in urls), "every URL is absolute http(s)")

print("\n=== 2. arithmetic reconciliation ===")
st = collections.Counter(r.get("status", "?") for r in V)
chk(len(V) == N["uniq"], f"validated set == unique candidates  ({f(N['uniq'])})")
chk(st["ok"]+st["skipped"]+st["bot-blocked"]+st["server-error"] == N["vkept"],
    f"validation pass buckets -> {f(N['vkept'])}")
chk(N["vkept"] + N["vfail"] == N["uniq"], f"{f(N['vkept'])} passed + {f(N['vfail'])} failed == {f(N['uniq'])}")
chk(N["total"] + N["dead"] + N["unsafe"] + N["low"] == N["uniq"],
    f"{f(N['total'])} kept + {f(N['dead'])} dead + {N['unsafe']} unsafe + {f(N['low'])} low-value == {f(N['uniq'])}")
chk(N["vfail"] - N["dead"] == N["overlap"],
    f"overlap (failures already caught by safety/low-value) == {N['overlap']}")
chk(N["core"] + N["adj"] == N["total"], f"core {f(N['core'])} + adjacent {f(N['adj'])} == {f(N['total'])}")
chk(sum(N["cats"].values()) == N["total"] and len(N["cats"]) == 17, "17 categories sum to total")
chk(N["cats"] == dict(collections.Counter(r["category"] for r in L)), "category counts match links.json")
chk(lines("data/all-links-core.txt") == N["core"], "all-links-core.txt == core count")
chk(lines("data/verified-live-only.txt") == N["live"], "verified-live-only.txt == live count")
chk(lines("data/dropped-dead-links.csv") - 1 == N["dead"], "dropped-dead-links.csv rows == dead count")
chk(lines("data/dropped-low-value-links.csv") - 1 == N["low"], "dropped-low-value csv rows == low-value count")
chk(lines("data/dropped-unsafe-ssrf-targets.txt") == N["unsafe"], "dropped-unsafe file == unsafe count")
pr = list(csv.DictReader(open("data/programs-ranked.csv", encoding="utf-8")))
chk(len(pr) == N["programs"], f"programs-ranked.csv rows == {f(N['programs'])}")

print("\n=== 3. safety ===")
UNSAFE = re.compile(r"(169\.254\.169\.254|metadata\.google\.internal|100\.100\.100\.200|"
                    r"fd00:ec2::254|localhost|127\.0\.0\.1|0\.0\.0\.0|\.internal$|\.local$)", re.I)
def priv(h):
    try: return ipaddress.ip_address(h).is_private
    except ValueError: return False
v = [u for u in urls if UNSAFE.search(urllib.parse.urlparse(u).netloc) or priv(urllib.parse.urlparse(u).netloc)]
chk(not v, f"no SSRF / cloud-metadata / private-IP URLs in corpus ({len(v)} found)")

print("\n=== 4. Antigravity rule package ===")
chk(len(rules) == N["rules"], f"{len(rules)} rule files")
big = max(os.path.getsize(r) for r in rules)
chk(big <= 24000, f"largest rule file {f(big)} B <= 24,000 B limit")
chk(all(open(r, encoding="utf-8").read(4) == "---\n" for r in rules), "every rule file has YAML frontmatter")
chk(sum(1 for r in rules if "trigger: always_on" in open(r, encoding="utf-8").read(120)) == 1,
    "exactly 1 always_on index + rest model_decision")
chk(all(re.search(r"^description:", open(r, encoding="utf-8").read(600), re.M)
        for r in rules if "model_decision" in open(r, encoding="utf-8").read(120)),
    "every model_decision rule has a description")

print("\n=== 5. internal document references ===")
cat  = {os.path.basename(p) for p in glob.glob("by-category/*.md")}
rset = {os.path.basename(p) for p in rules}
top  = {os.path.basename(p) for p in glob.glob("*.md")} | {"AGENTS.md"}
dat  = {os.path.basename(p) for p in glob.glob("data/*")}
bad = collections.Counter(); nref = 0
for d in glob.glob("*.md") + glob.glob("by-category/*.md") + glob.glob("antigravity/**/*.md", recursive=True):
    s = open(d, encoding="utf-8").read()
    for m in re.finditer(r"by-category/(\d\d-[a-z0-9\-]+\.md)", s):
        nref += 1
        if m.group(1) not in cat: bad[(d, "by-category/"+m.group(1))] += 1
    for m in re.finditer(r"`(\d\d-[a-z0-9\-]+(?:-part\d)?\.md)`", s):
        if m.group(1) not in rset and m.group(1) not in cat: bad[(d, m.group(1))] += 1
    for m in re.finditer(r"`([A-Z]+\.md)`", s):
        if m.group(1) not in top: bad[(d, m.group(1))] += 1
    for m in re.finditer(r"`data/([a-z0-9\-]+\.(?:csv|json|txt))`", s):
        if m.group(1) not in dat: bad[(d, "data/"+m.group(1))] += 1
chk(not bad, f"{nref} by-category refs + data/rule/doc refs all resolve ({len(bad)} broken)")
for (d, x), c in sorted(bad.items()): print(f"        {d}: {x} (x{c})")

print("\n=== 6. doc prose carries no stale figures ===")
stale = []
for d in glob.glob("*.md"):
    s = open(d, encoding="utf-8").read()
    for wrong in ("9,013", "9,881", "5,779", "10,113", "11,084", "65 rule files", "(0 templates)", "(0 pages)"):
        if wrong in s: stale.append((d, wrong))
chk(not stale, f"no stale numbers in prose ({len(stale)} found)")
for d, w in stale: print(f"        {d}: {w}")

print("\n" + ("=" * 62))
print(f"  {'ALL CHECKS PASSED' if not fails else str(len(fails)) + ' CHECK(S) FAILED'}")
print(f"  {f(N['total'])} verified URLs | {f(N['programs'])} bounty programs | "
      f"{len(rules)} rule files | 17 categories | max rule {f(big)} B")
sys.exit(1 if fails else 0)
